library(testthat)
library(jmnstore)

test_check("jmnstore")
